// Step 1: Import Twilio SDK
const twilio = require('twilio');

// Step 2: Add your Twilio credentials
const accountSid = 'AC1de49896e1da9e17574fae2e1bf8b288';
const authToken = '9c83a5dd348fe7c61bc4487c971a898a';
const client = twilio(accountSid, authToken);

// Step 3: Send the SMS
client.messages
  .create({
    body: `WageRadar – Job Confirmed ,
Work: Household Cleaning & Vessel Washing
Date: 22 Feb 2026
Time: 9:00 AM – 4:00 PM
Location: Near Govt School, Main Road, Ward-3
Wage: ₹600 (Cash/UPI after work)
Employer Contact: +91 9840895421

Please reach on time.
For any issue, reply HELP`,
    from: '+16615181361',  // Your Twilio phone number
    to: '+918807756796'    // The recipient’s mobile number
  })
  .then(message => console.log('✅ Message sent! SID:', message.sid))
  .catch(error => console.error('❌ Error:', error));